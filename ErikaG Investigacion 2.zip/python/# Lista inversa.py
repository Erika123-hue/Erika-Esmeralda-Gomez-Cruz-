# Lista inversa

# Creamos una lista del 10 al 1 en orden inverso
lista_inversa = list(range(10, 0, -1))

# Mostramos la lista
print("Lista en orden inverso:", lista_inversa)