# Contador de palabras

# Pedimos una frase al usuario
frase = input("Ingresa una frase: ")

# Separamos la frase en palabras y las contamos
palabras = frase.split()
cantidad = len(palabras)

# Mostramos el resultado
print(f"La frase contiene {cantidad} palabra(s).")