# Sumar elementos de una lista

# Lista predefinida
lista = [4, 7, 1, 3, 9]

# Calculamos la suma de los elementos
suma = sum(lista)

# Mostramos el resultado
print("La lista es:", lista)
print("La suma de los elementos es:", suma)