# Suma de dígitos

# Pedimos un número entero al usuario
numero = input("Ingresa un número entero: ")

# Calculamos la suma de los dígitos
suma = 0
for digito in numero:
    if digito.isdigit():  # Aseguramos que sea un dígito
        suma += int(digito)

# Mostramos el resultado
print(f"La suma de los dígitos es: {suma}")