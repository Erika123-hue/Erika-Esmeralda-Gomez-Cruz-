# Verificar si un número está en la lista

# Lista predefinida
lista = [3, 7, 10, 15, 20]

# Pedimos un número al usuario
numero = int(input("Ingresa un número para verificar si está en la lista: "))

# Verificamos si el número está en la lista
if numero in lista:
    print(f"El número {numero} **sí** está en la lista.")
else:
    print(f"El número {numero} **no** está en la lista.")