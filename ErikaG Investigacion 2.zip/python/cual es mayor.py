# Mayor de tres números

# Pedimos tres números al usuario
num1 = float(input("Ingresa el primer número: "))
num2 = float(input("Ingresa el segundo número: "))
num3 = float(input("Ingresa el tercer número: "))

# Determinamos el mayor
mayor = max(num1, num2, num3)

# Mostramos el resultado
print(f"El número mayor es: {mayor}")