# Números aleatorios

import random

# Generamos una lista con 5 números aleatorios entre 1 y 20
numeros_aleatorios = [random.randint(1, 20) for _ in range(5)]

# Mostramos la lista
print("Lista de 5 números aleatorios entre 1 y 20:", numeros_aleatorios)